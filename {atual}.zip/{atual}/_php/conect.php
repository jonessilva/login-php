<?php   
//Criar a conexao
$sql = new mysqli('sql203.epizy.com', 'epiz_24770842', '4Ok7ojdfI2B', 'epiz_24770842_teste');


